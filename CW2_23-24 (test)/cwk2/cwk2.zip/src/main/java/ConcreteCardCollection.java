public class ConcreteCardCollection extends CardCollection {
    // No additional methods needed, just allowing instantiation
}